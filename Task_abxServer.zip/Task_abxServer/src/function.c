/*********************************************************************************************
*
*       FILE NAME : server.c
*
*       DESCRIPTION : it include all the functionality of client
*
******************************************************************************************************/

/******************************************************************************************
*
*                                       HEADER FILES
*
****************************************************************************************************/
#include "header.h"

/*****************************************************************************************************
*
*       FUNCTION NAME : sendStream
*       DESCRIPTION : send all available ticker symbol
*       RETURNS : SUCCESS OR FAILURE
*
****************************************************************************************************/

void sendStream(int status) {
    //for Call Type 1: Stream All Packets
    uint8_t call_type = 1;

    send(status, &call_type, sizeof(call_type), 0);

    // The server will send packets for all available ticker symbols 
    //after that, the server will close the connection.
}

/*****************************************************************************************************
*
*       FUNCTION NAME : ResendPacket
*       DESCRIPTION : resend request 
*       RETURNS : SUCCESS OR FAILURE
*
****************************************************************************************************/

void resendPacket(int status, uint8_t resendSeq); {
    //for Call Type 2: Resend Packet
    uint8_t call_type = 2;

    send(status, &call_type, sizeof(call_type), 0);
    send(status, &resendSeq, sizeof(resendSeq), 0);

    // The server will send the requested packet
    // The server will not close the connection. client will close
}

/*****************************************************************************************************
*
*       FUNCTION NAME : readPacket
*       DESCRIPTION : read packet from server response
*       RETURNS : SUCCESS OR FAILURE
*
****************************************************************************************************/

bool readPacket(int status, Packet& packet) {
    if (recv(client_socket, &packet, sizeof(Packet), 0) != sizeof(Packet)) {
        // Failed to read a complete packet
        return false;
    }
    
    return true;
}