/*********************************************************************************************
*
*       FILE NAME : client.c
*
*       DESCRIPTION : it include all the functionality of client.
*
******************************************************************************************************/

/******************************************************************************************
*
*                                       HEADER FILES
*
****************************************************************************************************/
#include "header.h"
#define PORT 3000

/*****************************************************************************************************
*
*       FUNCTION NAME : main()
*       DESCRIPTION : it is client side main function which takes input as IP address ,port no of 
*	remote host.
*       RETURNS : SUCCESS OR FAILURE
*
****************************************************************************************************/
int main(int argc,char *argv[])
{
    int status= -1, valread = -1, client_fd = -1; 
    struct sockaddr_in server_addr; 

    //create a socket 
    if ((client_fd = socket(AF_INET, SOCK_STREAM, 0)) < 0) { 
        printf("\n Socket creation error \n"); 
        exit(-1);
    } 
  
    //set the details for server_addr structure
    memset(&server_addr,0,sizeof(server_addr));
    serv_addr.sin_family = AF_INET; 
    serv_addr.sin_port = htons(PORT); 
    server.sin_addr.s_addr = inet_addr(argv[1]); // ipaddress of server
  
    if (inet_pton(AF_INET, argv[1], &server_addr.sin_addr) <= 0) { 
        printf( 
            "\nInvalid address/ Address not supported \n"); 
        exit(-1); 
    } 
  
    //connect with the server
    if ((status = connect(client_fd, (struct sockaddr*)&server_addr, 
        sizeof(server_addr))) < 0) { 
        printf("\nConnection Failed \n"); 
        exit(-1); 
    }

    sendStream(status); //send stream of all packets.
    resendPacket(status, 42);  // Resend the stream of the sequence number.

    // Receive and process packets from server
    std::vector<Packet> packets;
    Packet packet;

    while (readPacket(status, packet)) {
        packets.push_back(packet);
    }

    // Processing the received packets
    for (const Packet &p : packets) {
        std::cout << "Symbol: " << p.symbol << ", Buy/Sell: " << p.buySellIndicator << ", Quantity: "
                  << p.quantity << ", Price: " << p.price << ", Packet Sequence: " << p.packetSequence << std::endl;
    }

    // closing the connected socket 
    close(status); 
    return 0;  
}



