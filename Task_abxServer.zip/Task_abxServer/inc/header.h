/*********************************************************************************************
*
*       FILE NAME : header.h
*
*       DESCRIPTION : it include all the header files,macros and function prototypes.
*
*       DATE    NAME    REFERENCE       REASON
*
*       copyright 2015 @Aricent Inc.
*
******************************************************************************************************/

/******************************************************************************************
*
*                                       HEADER FILES
*
****************************************************************************************************/
#include<string.h>
#include<stdio.h>
#include<stdlib.h>
#include<sys/types.h>
#include<sys/stat.h>
#include<sys/socket.h>
#include<fcntl.h>
#include<unistd.h>
#include<netinet/in.h>
#include<arpa/inet.h>
#include<errno.h>

/***************************************************************************************************************
*
*                                               MACROS
*
*************************************************************************************************************/
#define SUCCESS 0
#define FAILURE 1
#define MAX 300
#define PORT 3000 


/**********************************************************************************************************
*
*                                               STRUCTURE PROTOTYPE
*
***********************************************************************************************************/

struct Packet {
    char symbol[5];  
    char buySellIndicator;
    int32_t quantity;
    int32_t price;
    int32_t packetSequence;
};

/**********************************************************************************************************
*
*                                               FUNCTION PROTOTYPE
*
***********************************************************************************************************/
int sendStream(int sd,);
int resendPacket(int sd, uint8_t resendSeq);
bool readPacket(int sd, Packet& packet)

